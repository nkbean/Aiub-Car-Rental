import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Homepage {
    private JFrame frame;
    private JButton next;
    private JLabel label;

    public Homepage(){
        frame = new JFrame();
        frame.setTitle("AIUB RENTAL");
        frame.setSize(800,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());



        next = new JButton();
        next.setText("RENT");
        next.setFont(new Font("Serif", Font.BOLD, 30));
        next.setBackground(new Color(0x123456));
        next.setForeground(Color.WHITE);
        next.setBounds(600, 300, 150, 60);
        next.setFocusable(false);
        next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Reserve reserve = new Reserve();
                frame.dispose();
            }
        });
        frame.add(next);

        label = new JLabel();
        ImageIcon background = new ImageIcon("background.jpg");
        label.setIcon(background);
        label.setBounds(0,0,800,500);
        frame.add(label);

        frame.setVisible(true);
    }
}
