import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CarSelection {
    private JButton firstCarB, secondCarB,thirdCarB,forthCarB;
    private JFrame frame;
    private JLabel label;
    public CarSelection(){
        frame = new JFrame();
        frame.setTitle("AIUB RENTAL");
        frame.setSize(800,500);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        label = new JLabel("SELECT A CAR(Price 6000 Tk)");
        label.setBounds(170,20,500,50);
        label.setFont(new Font("SansSerif", Font.BOLD, 30));
        label.setForeground(Color.RED);
        frame.add(label);

        ImageIcon firstCarImage = new ImageIcon("Toyota1.jpg");
        firstCarB = new JButton(firstCarImage);
        firstCarB.setBounds(180, 100, 200, 125);
        firstCarB.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Toyota toyota = new Toyota();
                frame.dispose();
            }
        });
        frame.add(firstCarB);

        ImageIcon secondCarImage = new ImageIcon("Noah1.jpg");
        secondCarB = new JButton(secondCarImage);
        secondCarB.setBounds(420, 100, 200, 125);
        secondCarB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Noah noah = new Noah();
                frame.dispose();
            }
        });
        frame.add(secondCarB);

        ImageIcon thirdCarImage = new ImageIcon("Premio1.jpg");
        thirdCarB = new JButton(thirdCarImage);
        thirdCarB.setBounds(180, 250, 200, 125);
        thirdCarB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Allion allion = new Allion();
                frame.dispose();
            }
        });
        frame.add(thirdCarB);

        ImageIcon forthCarImage = new ImageIcon("Allion1.jpg");
        forthCarB = new JButton(forthCarImage);
        forthCarB.setBounds(420, 250, 200, 125);
        forthCarB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Premio premio = new Premio();
                frame.dispose();
            }
        });
        frame.add(forthCarB);

        frame.setVisible(true);
    }
}
