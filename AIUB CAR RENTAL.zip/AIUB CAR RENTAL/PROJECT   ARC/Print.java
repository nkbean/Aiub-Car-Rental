import javax.swing.*;
import java.awt.*;

public class Print extends setData {
    private JFrame frame;
    private JTextArea screen;
    static Customer c1;
    static Reserve r1;

    public Print(){

    }
    public Print(int x){

        frame = new JFrame();
        frame.setTitle("AIUB RENTAL");
        frame.setSize(800,500);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        screen = new JTextArea("      ------------------------AIUB Rental-----------------------"+"\n"+
                "   --------------------Owned & Operated By-------------------"+"\n"+
                "------------------------Nashib Khan & Amir Faisal ------------------------"+"\n"+"Name : "+c1.getFirstname()+" "+c1.getLastname()+
                "\n"+"Contact : "+c1.realContact()+"\n"+"Reserved for :"+r1.getDay()+" days"+"\n"+"Total cost :"+r1.Cost()+"\n"+
                "Date : "+r1.getDate()+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+"\n"+
                "--------------------Payment Complete----------------------"+"-------------Thank You for Renting-------------------");
        screen.setBounds(250,50,300,300);
        frame.add(screen);
        frame.setVisible(true);

    }
    public void addCustomer(Customer c1){
        this.c1 = c1;
    }
    public void addReserve(Reserve r1){
        this.r1 = r1;
    }


}
