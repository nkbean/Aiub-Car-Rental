public abstract class setData {

    abstract void addCustomer(Customer c1);
    abstract void addReserve(Reserve r1);
}
