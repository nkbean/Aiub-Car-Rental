public class Main {
    public static void main(String[] args) {
        Homepage rent = new Homepage();
    }
}