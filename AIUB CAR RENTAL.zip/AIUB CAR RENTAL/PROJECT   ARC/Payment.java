import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Payment implements WarningMessage {
    private JFrame frame;
    private JLabel pay, card, pin, bank1;
    private JTextField cardTF;
    private JPasswordField pass;
    private JButton previous, next;
    private JComboBox bank;
    public Payment(){
        frame = new JFrame();
        frame.setTitle("AIUB RENTAL");
        frame.setSize(800,500);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        String[] Bank = {"Sonali Bank Limited", "CITY Bank Limited", "Dutch-Bangla Bank"};
        bank = new JComboBox(Bank);
        bank.setBounds(200, 100, 200, 30);
        frame.add(bank);

        pay = new JLabel("Payment Option");
        pay.setFont(new Font("SansSerif", Font.BOLD, 30));
        pay.setForeground(Color.RED);
        pay.setBounds(100, 10, 500, 100);
        frame.add(pay);

        bank1 = new JLabel("Select Bank ");
        bank1.setFont(new Font("SansSerif", Font.BOLD, 15));
        bank1.setForeground(Color.RED);
        bank1.setBounds(100, 100, 100, 30);
        frame.add(bank1);

        card = new JLabel("Card Number");
        card.setFont(new Font("SansSerif", Font.BOLD, 15));
        card.setForeground(Color.RED);
        card.setBounds(100, 150, 100, 30);
        frame.add(card);

        pin = new JLabel("Pin Number ");
        pin.setFont(new Font("SansSerif", Font.BOLD, 15));
        pin.setForeground(Color.RED);
        pin.setBounds(100, 200, 100, 30);
        frame.add(pin);

        cardTF = new JTextField();
        cardTF.setHorizontalAlignment(JTextField.CENTER);
        cardTF.setForeground(Color.BLACK);
        cardTF.setBounds(200, 150, 250, 30);
        frame.add(cardTF);

        pass = new JPasswordField();
        pass.setEchoChar('*');
        pass.setHorizontalAlignment(JTextField.CENTER);
        pass.setForeground(Color. BLACK);
        pass.setBounds(200, 200, 250, 30);
        frame.add(pass);

        ImageIcon pre = new ImageIcon("customer_back.GIF");
        previous = new JButton(pre);
        previous.setBackground(Color.WHITE);
        previous.setBounds(30, 300, 100, 50);
        previous.setFocusable(false);
        previous.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CarSelection carSelection = new CarSelection();
                frame.dispose();
            }
        });
        frame.add(previous);

        next = new JButton();
        next.setText("RENT");
        next.setFont(new Font("Serif", Font.BOLD, 30));
        next.setBackground(new Color(0x123456));
        next.setForeground(Color.WHITE);
        next.setBounds(600, 300, 150, 60);
        next.setFocusable(false);
        next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                    try {
                        int cardno = Integer.parseInt(cardTF.getText());
                        if (pass.getPassword().length == 0) {
                            WarningMessage.warningPass();
                        } else {
                            Print print = new Print(1);
                            frame.dispose();
                        }
                    }
                    catch(Exception c){
                        WarningMessage.warningEnd();
                    }
            }
        });
        frame.add(next);

        frame.setVisible(true);
    }

}
