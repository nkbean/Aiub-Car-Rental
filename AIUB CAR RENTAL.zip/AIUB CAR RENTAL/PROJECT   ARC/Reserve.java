import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reserve {
    private JFrame frame;
    private JLabel headline,text1, text2;
    private JComboBox todayDate, todayMonth, todayYear, days;
     String date,date1;
     int day,day1,cost;
    private JButton previous,next1;


    public Reserve(){
        frame = new JFrame();
        frame.setTitle("Car Rent");
        frame.setSize(800,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        frame.setResizable(false);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());

        headline = new JLabel("Reserve Details");
        headline.setFont(new Font("SansSerif", Font.PLAIN, 30));
        headline.setForeground(Color.RED);
        headline.setBounds(100, 5, 500, 100);
        frame.add(headline);

        text1 = new JLabel("Today's Date");
        text1.setFont(new Font("SansSerif", Font.BOLD, 15));
        text1.setForeground(Color.RED);
        text1.setBounds(100, 50, 150, 100);
        frame.add(text1);

        text2 = new JLabel("Booking ");
        text2.setFont(new Font("SansSerif", Font.BOLD, 15));
        text2.setForeground(Color.RED);
        text2.setBounds(100, 120, 100, 100);
        frame.add(text2);

        Integer[] days_string = {1, 2, 3, 4, 5, 6, 7};
        days = new JComboBox(days_string);
        days.setBounds(200, 160, 60, 25);
        frame.add(days);

        String[] today_month = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        todayMonth = new JComboBox(today_month);
        todayMonth.setSelectedIndex(11);
        todayMonth.setBounds(200, 90, 60, 25);
        frame.add(todayMonth);

        Integer[] today_date = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
        todayDate = new JComboBox(today_date);
        todayDate.setBounds(265, 90, 60, 25);
        frame.add(todayDate);

        Integer[] today_year = { 2023, 2024, 2025};
        todayYear = new JComboBox(today_year);
        todayYear.setSelectedIndex(1);
        todayYear.setBounds(330, 90, 60, 25);
        frame.add(todayYear);



        ImageIcon next2 = new ImageIcon("customer.GIF");
        next1 = new JButton(next2);
        next1.setBackground(Color.WHITE);
        next1.setBounds(660, 300, 100, 50);
        next1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                date = todayDate.getSelectedItem()+"-"+todayMonth.getSelectedItem()+"-"+todayYear.getSelectedItem();
                day = (int) days.getSelectedItem();
                Reserve r = new Reserve(date, day);
                Print p1 = new Print();
                p1.addReserve(r);
                Customer customer = new Customer();
                frame.dispose();
            }
        });
        frame.add(next1);

        ImageIcon pre = new ImageIcon("customer_back.GIF");
        previous = new JButton(pre);
        previous.setBackground(Color.WHITE);
        previous.setBounds(530, 300, 100, 50);
        previous.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Homepage homepage = new Homepage();
                frame.dispose();
            }
        });
        frame.add(previous);

        frame.setVisible(true);
    }
    public Reserve(String x , int y){
        date1 = x;
        day1 = y;
    }
    public String getDate(){
        return date1;
    }
    public int getDay(){
        return day1;
    }
    public int Cost(){
        cost = day1*6000;
        return cost;
    }
}
