import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Customer implements WarningMessage{
    private JFrame frame;
    private JButton customerBackB,customerNextB;
    private JLabel customerL, firstNameL,lastNameL,genderL,locationL,ageL,contactL;
    private JTextField firstNameTF,lastNameTF,locationTF,contactTF,ageTF;
    private JRadioButton genderM, genderF;
    String firstname,lastname,real_contact,firstname1,lastname1,real_contact1;

    public Customer(){
        frame = new JFrame();
        frame.setTitle("Car Rent");
        frame.setSize(800,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());

        customerL = new JLabel("Customer's Data");
        customerL.setFont(new Font("SansSerif", Font.BOLD, 25));
        customerL.setForeground(Color.RED);
        customerL.setBounds(50, 10, 250, 30);
        frame.add(customerL);

        firstNameL = new JLabel("First Name");
        firstNameL.setFont(new Font("SansSerif", Font.BOLD, 15));
        firstNameL.setForeground(Color.RED);
        firstNameL.setBounds(50, 60, 250, 30);
        frame.add(firstNameL);

        lastNameL = new JLabel("Last Name");
        lastNameL.setFont(new Font("SansSerif", Font.BOLD, 15));
        lastNameL.setForeground(Color.RED);
        lastNameL.setBounds(50, 95, 250, 30);
        frame.add(lastNameL);

        genderL = new JLabel("Gender");
        genderL.setFont(new Font("SansSerif", Font.BOLD, 15));
        genderL.setForeground(Color.RED);
        genderL.setBounds(50, 130, 250, 30);
        frame.add(genderL);

        ageL = new JLabel("Age");
        ageL.setFont(new Font("SansSerif", Font.BOLD, 15));
        ageL.setForeground(Color.RED);
        ageL.setBounds(50, 165, 250, 30);
        frame.add(ageL);

        locationL = new JLabel("NID");
        locationL.setFont(new Font("SansSerif", Font.BOLD, 15));
        locationL.setForeground(Color.RED);
        locationL.setBounds(50, 200, 250, 30);
        frame.add(locationL);

        contactL = new JLabel("Contact");
        contactL.setFont(new Font("SansSerif", Font.BOLD, 15));
        contactL.setForeground(Color.RED);
        contactL.setBounds(50, 235, 250, 30);
        frame.add(contactL);


        firstNameTF = new JTextField();
        firstNameTF.setHorizontalAlignment(JTextField.CENTER);
        firstNameTF.setForeground(Color.BLACK);
        firstNameTF.setBounds(150, 60, 250, 30);
        frame.add(firstNameTF);

        lastNameTF = new JTextField();
        lastNameTF.setHorizontalAlignment(JTextField.CENTER);
        lastNameTF.setForeground(Color.BLACK);
        lastNameTF.setBounds(150, 95, 250, 30);
        frame.add(lastNameTF);

        genderM = new JRadioButton("Male");
        genderM.setBounds(150, 130, 100, 30);
        genderF = new JRadioButton("Female");
        genderF.setBounds(250, 130, 100, 30);
        genderM.setSelected(true);
        ButtonGroup gender = new ButtonGroup();
        gender.add(genderM);
        gender.add(genderF);
        frame.add(genderM);
        frame.add(genderF);


        ageTF = new JTextField();
        ageTF.setHorizontalAlignment(JTextField.CENTER);
        ageTF.setForeground(Color.BLACK);
        ageTF.setBounds(150, 165, 50, 30);
        frame.add(ageTF);

        locationTF = new JTextField();
        locationTF.setHorizontalAlignment(JTextField.CENTER);
        locationTF.setForeground(Color.BLACK);
        locationTF.setBounds(150, 200, 250, 30);
        frame.add(locationTF);

        contactTF = new JTextField();
        contactTF.setHorizontalAlignment(JTextField.CENTER);
        contactTF.setForeground(Color.BLACK);
        contactTF.setBounds(150, 235, 250, 30);
        frame.add(contactTF);


        ImageIcon customerNext = new ImageIcon("car.GIF");
        customerNextB = new JButton(customerNext);
        customerNextB.setBackground(Color.WHITE);
        customerNextB.setBounds(660, 300, 100, 50);
        customerNextB.setFocusable(false);
        customerNextB.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent e) {
                try {

                    int contact = Integer.parseInt(contactTF.getText());
                    int nid = Integer.parseInt(locationTF.getText());
                    int age = Integer.parseInt(ageTF.getText());
                    if ((firstNameTF.getText().isEmpty()) || (lastNameTF.getText().isEmpty()) || (ageTF.getText().isEmpty()) || (contactTF.getText().isEmpty()) || (locationTF.getText().isEmpty())) {
                        WarningMessage.warningEmpty();
                    }
                    else {
                        firstname = firstNameTF.getText();
                        lastname =lastNameTF.getText();
                        real_contact = contactTF.getText();
                        Customer c = new Customer(firstname,lastname,real_contact);
                        Print p = new Print();
                        p.addCustomer(c);

                        if ((age >= 18)) {
                            CarSelection carSelection=new CarSelection();
                            frame.dispose();
                        }
                        else {
                            WarningMessage.warningAge();
                        }
                    }
                }

                catch(Exception a){
                    WarningMessage.warningEnd();
                }
            }
        });

        frame.add(customerNextB);


        ImageIcon customerBack = new ImageIcon("customer_back.GIF");
        customerBackB = new JButton(customerBack);
        customerBackB.setBackground(Color.WHITE);
        customerBackB.setBounds(530, 300, 100, 50);
        customerBackB.setFocusable(false);
        customerBackB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Reserve reserve = new Reserve();
                frame.dispose();
            }
        });
        frame.add(customerBackB);

        frame.setVisible(true);
    }
    public Customer(String x, String y , String z) {
        firstname1 = x;
        lastname1=y;
        real_contact1=z;
    }
    public String getFirstname(){
        return firstname1;
    }
    public String getLastname(){
        return lastname1;
    }
    public String realContact(){
        return real_contact1;
    }






}