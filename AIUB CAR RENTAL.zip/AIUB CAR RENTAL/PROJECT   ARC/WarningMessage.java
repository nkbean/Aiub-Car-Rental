import javax.swing.*;

public interface WarningMessage {
    static void warningEmpty(){
        JOptionPane.showMessageDialog(null, "Please enter all information");
    }
    static void warningAge(){
        JOptionPane.showMessageDialog(null, "You must be older than 18");
    }
    static void warningEnd(){
        JOptionPane.showMessageDialog(null, "Please enter valid information");
    }
    static void warningPass(){
        JOptionPane.showMessageDialog(null, "Please enter password");
    }

}
