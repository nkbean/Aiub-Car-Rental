import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Noah {
    private JFrame frame;
    private JLabel label;
    private JButton next, previous;
    public Noah(){
        frame = new JFrame();
        frame.setTitle("AIUB RENTAL");
        frame.setSize(800,500);
        ImageIcon logo = new ImageIcon("Logo.jpg");
        frame.setIconImage(logo.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setResizable(false);

        next = new JButton();
        next.setText("RENT");
        next.setFont(new Font("Serif", Font.BOLD, 30));
        next.setBackground(new Color(0x123456));
        next.setForeground(Color.WHITE);
        next.setBounds(600, 300, 150, 60);
        next.setFocusable(false);
        next.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Payment pay = new Payment();
                frame.dispose();
            }
        });
        frame.add(next);
        previous = new JButton();
        previous.setText("BACK");
        previous.setBounds(430, 300, 150, 60);
        previous.setBackground(new Color(0x123456));
        previous.setFont(new Font("Serif", Font.BOLD, 30));
        previous.setForeground(Color.WHITE);
        previous.setFocusable(false);
        previous.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CarSelection carSelection = new CarSelection();
                frame.dispose();
            }
        });
        frame.add(previous);

        label = new JLabel();
        ImageIcon background = new ImageIcon("Noah2.png");
        label.setIcon(background);
        label.setBounds(0,0,800,500);
        frame.add(label);

        frame.setVisible(true);
    }
}
